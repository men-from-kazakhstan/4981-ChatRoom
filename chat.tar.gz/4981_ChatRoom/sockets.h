#ifndef SOCKETS_H
#define SOCKETS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <QMessageBox>

int setupClientSocket(int sock, sockaddr_in cltAddr, QWidget *parent);
int setupServerSocket(int sock, sockaddr_in srvAddr, sockaddr_in newAddr, QWidget *parent);

#endif // SOCKETS_H
