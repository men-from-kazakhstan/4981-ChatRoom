#include "sockets.h"

int setupClientSocket(int sock, sockaddr_in cltAddr, QWidget *parent)
{
    char *host = "127.0.0.1";

    if((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        QMessageBox::information(parent, "Error", "Failure to create socket");
        return -1;
    }
    else
    {
        QMessageBox::information(parent, "Info", "Socket created");
    }

    cltAddr.sin_family = AF_INET;
    cltAddr.sin_addr.s_addr = inet_addr(host);
    cltAddr.sin_port = htons(5150);

    if(connect(sock, (struct sockaddr *)&cltAddr, sizeof(cltAddr)) < 0)
    {
        QMessageBox::information(parent, "Error", "Failure to connect to server");
        return -1;
    }
    else
    {
        QMessageBox::information(parent, "Info", "Connected to server");
    }

    return 0;
}


int setupServerSocket(int sock, sockaddr_in srvAddr, sockaddr_in newAddr, QWidget* parent)
{
    socklen_t size;
    int arg = 1;

    if((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        QMessageBox::information(parent, "Error", "Failure to create socket");
        return -1;
    }
    else
    {
        QMessageBox::information(parent, "Info", "Socket created");
    }

    if(setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &arg, sizeof(arg)) < 0)
    {
        QMessageBox::information(parent, "Error", "Failure to set socket options");
        return -1;
    }
    else
    {
        QMessageBox::information(parent, "Info", "Set socket options");
    }

    srvAddr.sin_family = AF_INET;
    srvAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    srvAddr.sin_port = htons(5150);

    if(bind(sock, (struct sockaddr *)&srvAddr, sizeof(srvAddr)) < 0)
    {
        QMessageBox::information(parent, "Error", "Failure to bind socket");
        return -1;
    }
    else
    {
        QMessageBox::information(parent, "Info", "Socket bind successful");
    }

    listen(sock, 5);

    size = sizeof(newAddr);
    if(accept(sock, (struct sockaddr *)&newAddr, &size) < 0)
    {
        QMessageBox::information(parent, "Error", "Failure to accept socket");
        return -1;
    }
    else
    {
        QMessageBox::information(parent, "Info", "Client accepted");
    }

    return 0;
}
